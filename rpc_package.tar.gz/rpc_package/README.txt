Biblioteca RPC pentru utilizare în alte proiecte
